let token=localStorage.adminToken||"";
const $=id=>document.getElementById(id);
async function api(url,opt={}){opt.headers={...(opt.headers||{}),Authorization:"Bearer "+token,"Content-Type":"application/json"};let r=await fetch(url,opt);let j=await r.json().catch(()=>({}));if(!r.ok)throw Error(j.error||"Erro");return j}
async function login(){try{let r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:$("lu").value,password:$("lp").value})});let j=await r.json();if(!r.ok)throw Error(j.error);token=j.token;localStorage.adminToken=token;show()}catch(e){alert(e.message)}}
function logout(){localStorage.removeItem("adminToken");location.reload()}
function show(){$("login").classList.add("hidden");$("panel").classList.remove("hidden");loadAll()}
async function loadAll(){try{let s=await api("/api/dashboard");$("sClients").textContent=s.clients;$("sActive").textContent=s.active;$("sExpired").textContent=s.expired;$("sChannels").textContent=s.channels;renderClients(await api("/api/clients"));renderChannels(await api("/api/channels"))}catch(e){logout()}}
async function addClient(){try{let c=await api("/api/clients",{method:"POST",body:JSON.stringify({name:$("cn").value,username:$("cu").value,expiresAt:$("ce").value})});alert("Cliente criado.");$("cn").value=$("cu").value=$("ce").value="";loadAll()}catch(e){alert(e.message)}}
function renderClients(list){$("clientList").innerHTML=list.map(c=>`<div class="item"><div><b>${esc(c.name)}</b><small>Usuário: ${esc(c.username)} · validade: ${c.expiresAt} · ${c.active?"ativo":"bloqueado"}</small><small>Playlist: <a target="_blank" href="/playlist/${c.token}.m3u">Abrir M3U</a></small></div><div class="actions"><button onclick="toggleClient('${c.id}',${!c.active})">${c.active?"Bloquear":"Ativar"}</button><button onclick="copyM3U('${c.token}')">Copiar M3U</button><button class="danger" onclick="delClient('${c.id}')">Excluir</button></div></div>`).join("")||"<p>Nenhum cliente.</p>"}
async function toggleClient(id,v){await api("/api/clients/"+id,{method:"PATCH",body:JSON.stringify({active:v})});loadAll()}
async function delClient(id){if(confirm("Excluir cliente?")){await api("/api/clients/"+id,{method:"DELETE"});loadAll()}}
async function copyM3U(t){await navigator.clipboard.writeText(location.origin+"/playlist/"+t+".m3u");alert("Link M3U copiado.")}
async function addChannel(){try{await api("/api/channels",{method:"POST",body:JSON.stringify({name:$("chName").value,category:$("chCat").value,url:$("chUrl").value,logo:$("chLogo").value})});["chName","chCat","chUrl","chLogo"].forEach(x=>$(x).value="");loadAll()}catch(e){alert(e.message)}}
function renderChannels(list){$("channelList").innerHTML=list.map(c=>`<div class="item"><div><b>${esc(c.name)}</b><small>${esc(c.category)} · ${esc(c.url)}</small></div><div class="actions"><button class="danger" onclick="delChannel('${c.id}')">Excluir</button></div></div>`).join("")||"<p>Nenhum canal.</p>"}
async function delChannel(id){if(confirm("Excluir canal?")){await api("/api/channels/"+id,{method:"DELETE"});loadAll()}}
function tab(t){$("clients").classList.toggle("hidden",t!=="clients");$("channels").classList.toggle("hidden",t!=="channels")}
function esc(x){return String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
if(token)show();